import styles from "./styles.module.scss";

export default function ContentWrapper() {
  return <main className={styles.main}></main>;
}
