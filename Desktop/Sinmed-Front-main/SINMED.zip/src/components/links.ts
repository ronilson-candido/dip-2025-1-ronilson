export const links = [
  {
    name: "Home",
    path: "/",
  },
  {
    name: "Sindicato",
    path: "/historia",
  },
  {
    name: "Jurídico",
    path: "/juridico",
  },
  {
    name: "Outros",
    path: "/outros",
  },
];
