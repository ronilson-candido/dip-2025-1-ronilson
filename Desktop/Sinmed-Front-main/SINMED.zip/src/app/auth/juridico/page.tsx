import LoggedContainer from "@/components/UI/AreaDoFiliado/logged-container";
import styles from "./styles.module.scss";

export default function Juridico() {
  return (
    <LoggedContainer>
      <h1></h1>
    </LoggedContainer>
  );
}
