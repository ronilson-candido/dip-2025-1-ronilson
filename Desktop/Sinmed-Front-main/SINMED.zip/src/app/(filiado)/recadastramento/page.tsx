import LeftWindowRec from "@/components/UI/AreaDoFiliado/LeftLoginWindowRec";
import styles from "./page.module.scss";
import FiliadoContainerRec from "@/components/UI/AreaDoFiliado/filiado-container-rec";
import RegisterFormRec from "@/components/Forms/RegisterFormRec";
import { Metadata } from "next";

export const metadata: Metadata = {
  title: "Registro | SINMED-AL",
  description: "Tela de Registro Sinmed Alagoas",
};

export default function Registro() {
  return (
    <FiliadoContainerRec>
      <LeftWindowRec />
      <RegisterFormRec />
    </FiliadoContainerRec>
  );
}
