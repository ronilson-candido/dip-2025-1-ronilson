"use client";
import { useRouter, useSearchParams } from "next/navigation";
import styles from "./page.module.scss";
import Header from "@/components/Header";

export default function Redirecionamento() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const userName = searchParams.get("name");

  return (
    <div className={styles.redirectionArea}>     
      <h2>Olá, {userName}!</h2>
      <p>
        De acordo com as instruções da SINMED, é necessário realizar um novo
        recadastramento para continuar acessando nossos serviços.
      </p>
      <button
        className={styles.startButton}
        onClick={() => router.push("/recadastramento")}
      >
        Vamos começar
      </button>
    </div>
  );
}
