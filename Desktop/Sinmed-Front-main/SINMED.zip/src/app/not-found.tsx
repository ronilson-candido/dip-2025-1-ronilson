export default function NotFound() {
  return <h1>Página não encontrada</h1>;
}
