import Header from "@/components/Header";

export default function Sindicato() {
  return (
    <>
      <Header />
      <h1>Sindicato</h1>
    </>
  );
}
