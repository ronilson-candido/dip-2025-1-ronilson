import { Metadata } from "next";

export const metadata: Metadata = {
  title: "SINMED AL - Multimídia",
  description: "Multimídia | SINMED-AL",
};

export default function Multimidia() {
  return <h1>Multimidia</h1>;
}
